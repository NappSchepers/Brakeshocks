/*
 * ShockMeasurement.c
 *
 * PROJECT: SCHIRTE (Schock Intensit�ten Resistenz Test Einrichtung)
 * 
 * Created: 23.11.2021 16:36:55
 * Author : Sarah Napp (geb. Schwarzer)
 * Versions: 
 * 0.01 First Draft Version, including the basic libraries for ADC and data transmission
 * 0.02 / 23.11.2021:	Implemented the shock measurement procedure and data sorting procedure
 *							Note1: Check if test measurements in ADC_init functions are really necessary
 *							Note2: Maybe a separate function for data transfer could be implemented
 * 0.03 / 25.11.2021:	Test measurements in ACD_init functions was commented out. This is not necessary
 *							because ADCs run in contiunous mode, i.e. many measurements are taken before shock occurs
 *						ADC_init functions were updated, now both channels are initialized accordingly
 *						Data transfer topic is not solved yet. At the moment, data is transferred via USART after
 *						shock event. Maybe data can be written to flash memory? 
 * 0.04 / 06.12.2021	A loop was added in order to fill the data array with valid values before triggering. 
 * 0.05 / 06.12.2021	Before data is sent, all data is set around zero line and then converted from voltage to acceleration
 * 0.06 / 04.06.2024    Software was originally developed for AVR128DA48 evaluation board and was now adapted to 
 *                      internally developed SCHIRTE hardware based on AVR128DA28
 * 0.07 / 08.07.2024    Software will be adapted to the new SCHIRTE hardware using the option of dual channel ADC readout
 *                      or consecutive readout of the two channels. Options can be choosen by dip switch. 
 *                      For this purpose, one additional variable is introduced: readout_option, description see below.
 *                      Furthermore, two sub-functions where defined for reading out data in parallel or consecutively. 
 *                      Some global variables where moved into these funtions in order to make them local variables and 
 *                      to save (global) memory. 
 * 0.08 / 16.07.2024    Minor changes (renaming of variables, adding of comments) after software review 
 * 0.09 / 17.07.2024    Bug was eliminated in double channel measurement, the conversion of z axis data was not correct
 * 0.10 / 17.07.2024    Two separate variables for independent calibration of zerolines for x and y axis were introduced
 * 0.11 / 17.07.2024    Time measurement was added for single and double channel readout (later was commented out agein). 
 * 0.12 / 25.06.2025    Conversion factor was not correct and was adapted to correct value (old value: 4mV/g, new value: 0.63mV/g)
 *                          and trigger level was set to ~100g (ADC value 2097)
 * 0.13 / 17.07.2025    Conversion factor was modified for 3.3 V supply and trigger level set to 100g with modified conversion factor. 
 * 0.14 / 31.03.2026    An auto-zero function was added. The function takes the first 10 % of the measured values (i. e. vales before 
 *                          the shock) in order to eliminate possible voltage offset for setting the zero line. 
 *                          The auto-zero functions are included in functions Read_dual_channels/Read_single_channels.
 * 1.0 / 27.05.2026     Version 1.0 released after adding more comments for better understanding of the software code.  
 *                      Unnecessary code fragments were deleted. 
 *                         
 */ 


// Note: Supply voltage of micro-controller was set to 5 V. This can be done in Atmel Studio (Tools/Device Programming/Tool Settings; choose nEDBG/Apply before)
// The 5 V supply voltage will be applied as reference voltage for ADCs, i. e. resolution is 5V/4095 = 1,22 mV. 

// Define CPU Speed as Unsigned Long (UL)
// This is necessary for delay function (delay.h) and USART function
#define F_CPU 24000000UL
// Note: Baud rate must be set to 9600 for bluetooth transfer with HC-05 BT module
// see Uart1_init() for baud rate setting
#define USART1_BAUD_RATE(BAUD_RATE)     ((float)(64 * F_CPU / (16 * (float)BAUD_RATE)) + 0.5)

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <avr/cpufunc.h>


// Timer will count until maximum (of 16 bit)
#define TIMER_PERIOD 0xFFFF

// Definition of Variables
// For time measurement only
// uint16_t test;


// ATTENTION: TRIGGERVALUES + DELTA must equal to ADCVALUES!
// Zero line of sensor (for calibration of zero line), here: default value,
// autozero function is integrated in read channel functions
uint16_t X_ZEROLINE = 2047;
uint16_t Z_ZEROLINE = 2047;

// conversion factor (3.3 Volt range, 12 bits (4095 steps), sensitivity 0.63 mV/g):
float CONFACTOR = (3.3/4095.0)/0.00063;


// threshold level for trigger event (depends on the voltage range and resolution, here 3.3 V range and 0 - 4095 (12 bit resolution)
// THRESLEVEL = Triggerlevel * 4095 * 0.00063 / 3.3 + 2047
// Example: If the measurement system shall trigger at accelerations > 50 g, then THRESLEVEL can be calculated to:
// THRESLEVEL = 50 * 4095 * 0.00063 / 3.3 + 2047 =~ 2087
// Standard trigger level is 50 g, this corresponds to THRESLEVEL = 2087)
uint16_t THRESLEVEL = 2087;	 
// counter variable
uint16_t i;
// position index of the trigger within the data array
int16_t trigger_pos; 
// counter index after trigger event
uint16_t trigger_count; 
// counter variable for measurement loop
uint8_t x; 
// variables for sorting procedure
uint16_t j;
uint16_t sortindex;
// necessary shift of data within the array (for sorting the data within the array)
int16_t offset;        
// temporary variable for sorting the x data
uint16_t xtemp;        
// temporary variable for sorting the z data
uint16_t ztemp;  

// Readout option depends on the position of the dip switch. 
// If switch is in "on" position, PIN PD6 is low (= dual channel readout). 
// If switch is in "off" position, PIN PD6 is high (= consecutive single channel readout). 
uint16_t readout_option;

// Function Definitions
// Clock Control
void CLKCTRL_init(void);

// Single Ended Conversion
// x-axis at pin PD3
// y-axis at pin PD4 (not applied at the moment)
// z-axis at pin PD5
void ADC0_init(void);
uint16_t ADC0_read_CH3(void); // Pin PD3
uint16_t ADC0_read_CH5(void); // Pin PD5
// Pin PD6 is connected to dip switch for choosing readout option
// (dual channel or consecutive single channel readout)
uint16_t ADC0_read_CH6(void); // Pin PD6

// read channels in parallel
void Read_dual_channels(void); 
// read channels consecutively
void Read_single_channels(void);

// Definition of USART functions
// Note: USART frequency is set to 9600 baud in init-function
void USART1_init(void);
void USART1_sendChar(char c);
void USART1_sendString(const char *str);

// Definition of string functions
// Require #include <math.h>, <stdio.h> and <string.h>
// Helper functions
void reverse(char* str, int len);
int intToStr(int x, char str[], int d);
// Converts a floating-point/double number to a string.
void ftoa(float n, char* res, int afterpoint);

// For time measurement
void starttimer(void);

// long int variable for values around zero line
int16_t zerovalues; 
// float value to convert voltage to acceleration
float acceleration; 
// String array which hold the converted number for USART transmission
char strnum[20];

int main(void)
{
	
	// Initialize all hardware components
	CLKCTRL_init();
	USART1_init();
	ADC0_init();	
    _delay_ms(100);
    			
	// "Operating System"
	while (1)
	{
		// Clock frequency is set to 24 MHz. 
        // Time measurements have shown, that the ADC acquisition rate is 
        // 55.422849 kHz per channel in double channel mode and
        // 97.553362 kHz in (consecutive) single channel mode. 
		// The exact sampling rate has to be verified. When the exact sampling rate is known, the number of adc values has to
		// be adapted accordingly (modify constant ADVALUES and if this constant is modified, also TRIGGERVALUES and DELTA 
		// must be modified in order to match the desired signal length of 50 ms! 
		
        readout_option = ADC0_read_CH6();
        
        // If dip switch is in "on" position, PIN PD6 is low and both channels shall be read out in parallel.  
        if (readout_option < 2000) {
            Read_dual_channels();
        }
       
        // If dip switch is in "off" position, PIN PD6 is high and both channels shall be read out consecutivly.
        else {
            Read_single_channels();
            
        }
				
	}
}

// Function Definitions

// This function initializes the CLKCTRL module
//*********************************************************
void CLKCTRL_init(void)
{   
    // External 24 MHz oscillator
    // Switch to external clock
    _PROTECTED_WRITE(CLKCTRL_MCLKCTRLA,CLKCTRL_CLKSEL_EXTCLK_gc);
    // Wait until clock change is finished
    while(CLKCTRL.MCLKSTATUS&CLKCTRL_SOSC_bm) {}
}
//*********************************************************



// ***********************************************************
// Functions for Single Ended Conversion
void ADC0_init(void)
{
	// Disable digital input buffer PIN 3/5/6
	PORTD.PIN3CTRL &= ~PORT_ISC_gm;
	PORTD.PIN3CTRL |= PORT_ISC_INPUT_DISABLE_gc;
	PORTD.PIN5CTRL &= ~PORT_ISC_gm;
	PORTD.PIN5CTRL |= PORT_ISC_INPUT_DISABLE_gc;
    PORTD.PIN6CTRL &= ~PORT_ISC_gm;
	PORTD.PIN6CTRL |= PORT_ISC_INPUT_DISABLE_gc;
	// Disable pull-up resistor PIN 3/5
	PORTD.PIN3CTRL &= ~PORT_PULLUPEN_bm;
	PORTD.PIN5CTRL &= ~PORT_PULLUPEN_bm;
    PORTD.PIN6CTRL &= ~PORT_PULLUPEN_bm;
		
	VREF.ADC0REF = VREF_REFSEL_VDD_gc; 
	ADC0.CTRLC = ADC_PRESC_DIV8_gc;
	ADC0.CTRLA = ADC_ENABLE_bm | ADC_RESSEL_12BIT_gc; // ADC Enable: enabled and 12-bit mode
	
}

uint16_t ADC0_read_CH3(void)
{
	// Select ADC channel
	ADC0.MUXPOS = ADC_MUXPOS_AIN3_gc;
	
	// Start ADC conversion
	ADC0.COMMAND = ADC_STCONV_bm;
	// Wait until ADC conversion done
	while ( !(ADC0.INTFLAGS & ADC_RESRDY_bm) )
	{
		// Do nothing until conversion is done
	}
	// Clear the interrupt flag by writing 1:
	ADC0.INTFLAGS = ADC_RESRDY_bm;
	return ADC0.RES;
}

uint16_t ADC0_read_CH5(void)
{
	// Select ADC channel
	ADC0.MUXPOS = ADC_MUXPOS_AIN5_gc;
	
	// Start ADC conversion
	ADC0.COMMAND = ADC_STCONV_bm;
	// Wait until ADC conversion done
	while ( !(ADC0.INTFLAGS & ADC_RESRDY_bm) )
	{
		// Do nothing until conversion is done
	}
	// Clear the interrupt flag by writing 1:
	ADC0.INTFLAGS = ADC_RESRDY_bm;
	return ADC0.RES;
}

uint16_t ADC0_read_CH6(void)
{
	// Select ADC channel
	ADC0.MUXPOS = ADC_MUXPOS_AIN6_gc;
	
	// Start ADC conversion
	ADC0.COMMAND = ADC_STCONV_bm;
	// Wait until ADC conversion done
	while ( !(ADC0.INTFLAGS & ADC_RESRDY_bm) )
	{
		// Do nothing until conversion is done
	}
	// Clear the interrupt flag by writing 1:
	ADC0.INTFLAGS = ADC_RESRDY_bm;
	return ADC0.RES;
}


// Functions for USART data transmission
//*************************************************************
void USART1_init(void)
{
	PORTC.DIRSET = PIN0_bm;                             // set pin 0 of PORT C (TXd) as output
	PORTC.DIRCLR = PIN1_bm;                             // set pin 1 of PORT C (RXd) as input
	
	//USART1.BAUD = (uint16_t)(USART1_BAUD_RATE(9600));   // set the baud rate
    USART1.BAUD = (uint16_t)(USART1_BAUD_RATE(115200));   // set the baud rate
	// Not necessary? Or use alternativ implementation? 
    //USART1.CTRLC = USART_CHSIZE0_bm	| USART_CHSIZE1_bm; // set the data format to 8-bit
	USART1.CTRLB |= USART_TXEN_bm;                      // enable transmitter
    
}

void USART1_sendChar(char c)
{
	while(!(USART1.STATUS & USART_DREIF_bm))
	{
		;
	}
	
	USART1.TXDATAL = c;
}

void USART1_sendString(const char *str)
{
	for(size_t i = 0; i < strlen(str); i++)
	{
		USART1_sendChar(str[i]);
	}
}
//*************************************************************




// Function for num2str conversion
//************************************************************
// Reverses a string 'str' of length 'len'
void reverse(char* str, int len)
{
	int i = 0, j = len - 1, temp;
	while (i < j) {
		temp = str[i];
		str[i] = str[j];
		str[j] = temp;
		i++;
		j--;
	}
}

// NOTE: If more positions after decimal points shall be 
// converted with the following functions intToStr and ftoa, 
// "int x" must be set to "long long x" and 
// "float n" to "double n". 
// Or to be platform independent, "int x" could be set to
// "uint64_t"? This was not verified yet. 
// If you receive corrupted data, the reason might be found
// in the conversion function, as many decimal places lead to
// a variable overflow. 

// Converts a given integer x to string str[].
// d is the number of digits required in the output.
// If d is more than the number of digits in x,
// then 0s are added at the beginning.
int intToStr(int x, char str[], int d)
{
	int i = 0;
	while (x) {
		str[i++] = (x % 10) + '0';
		x = x / 10;
	}
	
	// If number of digits required is more, then
	// add 0s at the beginning
	while (i < d)
	str[i++] = '0';
	
	reverse(str, i);
	str[i] = '\0';
	return i;
}

// Converts a floating-point/double number to a string.
void ftoa(float n, char* res, int afterpoint)
{
	uint8_t sgn = 0;
	char strneg[20] = "-";
	// if number n is negative
	if(n < 0.0) {
		n = n * (-1.0);
		sgn = 1;
	}
	
	// Extract integer part
	int ipart = (int)n;
	
	// Extract floating part
	float fpart = n - (float)ipart;
	
	// convert integer part to string
	int i = intToStr(ipart, res, 0);
	
	// check for display option after point
	if (afterpoint != 0) {
		res[i] = '.'; // add dot
		
		// Get the value of fraction part upto given no.
		// of points after dot. The third parameter
		// is needed to handle cases like 233.007
		fpart = fpart * pow(10, afterpoint);
		
		intToStr((int)fpart, res + i + 1, afterpoint);
	}
	
	// if number n was negative, add "-" to string
	if(sgn == 1) {
		strcat(strneg, res);
		strcpy(res, strneg); 
	}
}



//************************************************************



// For time measurement only
//***********************************************************
void starttimer(void){
	// TCA0.SINGLE.INTCTRL = TCA_SINGLE_OVF_bm;
	TCA0.SINGLE.CTRLB = TCA_SINGLE_WGMODE_NORMAL_gc;
	TCA0.SINGLE.PER = TIMER_PERIOD;
	// TCA0.SINGLE.CTRLA = TCA_SINGLE_CLKSEL0_bm;
	TCA0.SINGLE.CTRLA |= TCA_SINGLE_CLKSEL_DIV1_gc;
	TCA0.SINGLE.CTRLA |= TCA_SINGLE_ENABLE_bm;
}
// **********************************************************


// Readout functions
//***********************************************************

// If dip switch is in "on" position, PIN PD6 is low and both channel shall be read out in parallel. 
void Read_dual_channels(void) {
    // Set local variables
    // Variables for Data Acquisition
    // number of ADC values (depend on the desired time interval (here: 50 ms) and sampling rate)
    uint16_t ADCVALUES = 3000; 
    // number of values which shall be sampled after a trigger event (here: 35 ms)
    uint16_t TRIGGERVALUES = 2100; 
    // number of values before trigger event (here: 15 ms)
    uint16_t DELTA = 900;
    // measurement data z axis, array size must correspond to ADCVALUES!
    uint16_t xadcval[3000];
    // measurement data z axis, array size must correspond to ADCVALUES!
    uint16_t zadcval[3000];
    // variable for setting zero line
    uint32_t autozerox = 0; 
    uint32_t autozeroz = 0;
    
    // Set all values to default		
    i = 0;
    x = 1;
    trigger_pos = -1;
    trigger_count = 0;
    

    // Read ADC values once in order to fill the data array with valid values before triggering. 
    // Shifting the array will lead to invalid values without previous filling. 
    for(i = 0; i < ADCVALUES - 1; i++){

        // Read x axis and z axis on pins PD3 and PD5
        xadcval[i] = ADC0_read_CH3();
        zadcval[i] = ADC0_read_CH5();
    }

    
    // The following loop is for data acquisition. In this software version, x and z axis will be sampled. A third axis (y) can easily be added. 
    // 12500 values will be sampled every 4 �s. This corresponds to a signal length of 50 ms (might be necessary to modify, see above). 
    // The loop for data acquisition is an endless loop. This loop will only be left, when an trigger event is tripped (adc value above threshold). 
    // Before leaving the loop, 8750 more values will be sampled (corresponds to 35 ms). Together with the trigger index, data can be sorted so that
    // the array contains 15 ms of data before the trigger event and 35 ms of data after the trigger event. 
    while(x > 0){
        
        // Read x axis and z axis on pins PD3 and PD5
        xadcval[i] = ADC0_read_CH3();
        zadcval[i] = ADC0_read_CH5();

        // If adc value is above threshold level, save trigger event index
        if((trigger_pos < 0) && ((xadcval[i] > THRESLEVEL) || (zadcval[i] > THRESLEVEL))){
            trigger_pos = i;
        }
        // increment counter
        i++;
        // when the counter reaches the end of the array: set counter to 0
        // that means, the measurement values are written continuously into the array
        if(i >= ADCVALUES){
            i = 0;
        }
        // If an trigger event was tripped: Start counting the number of measurements after trigger event
        if(trigger_pos >= 0){
            trigger_count++;
        }
        // Sample the desired number of measurement values after trigger event (here: 35 ms after trigger event), 
        // when the number of desired values is reached, leave the data acquisition loop
        if(trigger_count >= TRIGGERVALUES){
            x = 0;
        }
        // end of data acquisition loop
        
    }
    USART1_sendString("University of Applied Sciences Ruhr West, Napp/Schepers, SCHIRTE V3.0 \r\n");
    USART1_sendString("Trigger! Data will be transferred: \r\n");
    //_delay_ms(100);

    // Sorting procedure for data within arrays for x and z axis (i.e. 15 ms before and 35 ms after trigger event)
    // data will be shifted by DELTA positions within the arrays
    offset = trigger_pos - DELTA;

    if(offset > 0){
        // Shift array elements to the left
        for(i = 1; i <= offset; i++){
            // Saving the value of the first array element
            xtemp = xadcval[0];
            ztemp = zadcval[0];

            for(j = 0; j < ADCVALUES - 1; j++){

                // Sorting index is set to the next field
                // and content will be written to actual field
                sortindex = j + 1;
                xadcval[j] = xadcval[sortindex];
                zadcval[j] = zadcval[sortindex];
            }

            // Content of the first array element is written to the last position of the array. 
            xadcval[ADCVALUES - 1] = xtemp;
            zadcval[ADCVALUES - 1] = ztemp;
        }
    }
    else if(offset < 0){
        // shift array elements to the right
        offset = offset*(-1);
        for(i = 1; i <= offset; i++){
            // Saving the value of the last array element
            xtemp = xadcval[ADCVALUES - 1];
            ztemp = zadcval[ADCVALUES - 1];

            for(j = 0; j < ADCVALUES - 1; j++){

                // Start with the last array element and after that the counter moves step by step to the left, 
                // i. e. sorting index is decremented and content will be written to the actual element. 
                // Thus the content is moved to the right. 
                sortindex = ADCVALUES - j - 2;

                xadcval[ADCVALUES - j - 1] = xadcval[sortindex];
                zadcval[ADCVALUES - j - 1] = zadcval[sortindex];

            }
            // Writing the content of the last element into the first field of the array. 
            xadcval[0] = xtemp;
            zadcval[0] = ztemp;
        }
    }
    
    // autozero function x axis (first 10% of total values)
    for(i = 0; i <= 299; i++){
        autozerox = autozerox + xadcval[i];
    }
    X_ZEROLINE = autozerox / 300;
    // autozero function z axis (first 10% of total values)
    for(i = 0; i <= 299; i++){
        autozeroz = autozeroz + zadcval[i];
    }
    Z_ZEROLINE = autozeroz / 300;

    // Sending all x values via USART
    USART1_sendString("Shock data x axis: \r\n");
    for(i = 0; i <= (ADCVALUES - 1); i++){
        // Shift data to zero line and
        // convert voltage to acceleration
        zerovalues = xadcval[i] - X_ZEROLINE;
        acceleration = (float)zerovalues;
        acceleration = acceleration * CONFACTOR;
        // Convert data to string
        ftoa(acceleration, strnum, 2);
        // Send data
        USART1_sendString(strnum);
        USART1_sendString(" ");

    }
    // End of data transfer
    USART1_sendString("\r\n");
    USART1_sendString("------------------------");

    // Sending all z values via USART
    USART1_sendString("Shock data z axis: \r\n");
    for(i = 0; i <= (ADCVALUES - 1); i++){
        /// Shift data to zero line and
        // convert voltage to acceleration
        zerovalues = zadcval[i] - Z_ZEROLINE;
        acceleration = (float)zerovalues;
        acceleration = acceleration * CONFACTOR;
        
        // Convert data to string
        ftoa(acceleration, strnum, 2);
        // Send data
        USART1_sendString(strnum);
        USART1_sendString(" ");

    }
    // End of data transfer
    USART1_sendString("\r\n");
    USART1_sendString("------------------------"); 
    
}

//*************************************************

// If dip switch is in "off" position, PIN PD6 is high and both channel shall be read out consecutively. 
void Read_single_channels(void) {
    // Set local variables
    
    // Variables for Data Acquisition
    // number of ADC values (depend on the desired time interval (here: 50 ms) and sampling rate)
    uint16_t ADCVALUES = 6000; 
    // number of values which shall be sampled after a trigger event (here: 35 ms)
    uint16_t TRIGGERVALUES = 4200; 
    // number of values before trigger event (here: 15 ms)
    uint16_t DELTA = 1800;
    // measurement data for each axis, array size must correspond to ADCVALUES!
    uint16_t adcval[6000];
     // variable for setting zero line
    uint32_t autozerox = 0; 
    uint32_t autozeroz = 0;  
    
    // First step: Read x-axis!
    
    // Set all values to default		
    i = 0;
    x = 1;
    trigger_pos = -1;
    trigger_count = 0;

    // Read ADC values once in order to fill the data array with valid values before triggering. 
    // Shifting the array will lead to invalid values without previous filling. 
    for(i = 0; i < ADCVALUES - 1; i++){

        // Read x axis on pin PD3
        adcval[i] = ADC0_read_CH3();
    }

     // The following loop is for data acquisition. In this software version, x and z axis will be sampled. A third axis (y) can easily be added. 
    // 12500 values will be sampled every 4 �s. This corresponds to a signal length of 50 ms (might be necessary to modify, see above). 
    // The loop for data acquisition is an endless loop. This loop will only be left, when an trigger event is tripped (adc value above threshold). 
    // Before leaving the loop, 8750 more values will be sampled (corresponds to 35 ms). Together with the trigger index, data can be sorted so that
    // the array contains 15 ms of data before the trigger event and 35 ms of data after the trigger event. 
    while(x > 0){      
        
        // Read x axis on pin PD3
        adcval[i] = ADC0_read_CH3();

        // If adc value is above threshold level, save trigger event index
        if((trigger_pos < 0) && ((adcval[i] > THRESLEVEL))){
            trigger_pos = i;
        }
        // increment counter
        i++;
        // when the counter reaches the end of the array: set counter to 0
        // that means, the measurement values are written continuously into the array
        if(i >= ADCVALUES){
            i = 0;
        }
        // If an trigger event was tripped: Start counting the number of measurements after trigger event
        if(trigger_pos >= 0){
            trigger_count++;
        }
        // Sample the desired number of measurement values after trigger event (here: 35 ms after trigger event), 
        // when the number of desired values is reached, leave the data acquisition loop
        if(trigger_count >= TRIGGERVALUES){
            x = 0;
        }
        // end of data acquisition loop
        
    }
    USART1_sendString("University of Applied Sciences Ruhr West, Napp/Schepers, SCHIRTE V3.0 \r\n");
    USART1_sendString("Trigger! Data will be transferred: \r\n");
    //_delay_ms(100);

    // Sorting procedure for data within array for x axis (i.e. 15 ms before and 35 ms after trigger event)
    // data will be shifted by DELTA positions within the arrays
    offset = trigger_pos - DELTA;

    if(offset > 0){
        // Shift array elements to the left
        for(i = 1; i <= offset; i++){
            // Saving the value of the first array element
            xtemp = adcval[0];
            
            for(j = 0; j < ADCVALUES - 1; j++){

                // Sorting index is set to the next field
                // and content will be written to actual field
                sortindex = j + 1;
                adcval[j] = adcval[sortindex];
               
            }

            // Content of the first array element is written to the last position of the array. 
            adcval[ADCVALUES - 1] = xtemp;
           
        }
    }
    else if(offset < 0){
        // shift array elements to the right
        offset = offset*(-1);
        for(i = 1; i <= offset; i++){
            // Saving the value of the last array element
            xtemp = adcval[ADCVALUES - 1];

            for(j = 0; j < ADCVALUES - 1; j++){

                // Start with the last array element and after that the counter moves step by step to the left, 
                // i. e. sorting index is decremented and content will be written to the actual element. 
                // Thus the content is moved to the right. 
                sortindex = ADCVALUES - j - 2;

                adcval[ADCVALUES - j - 1] = adcval[sortindex];

            }
            // Writing the content of the last element into the first field of the array. 
            adcval[0] = xtemp;
        }
    }
    
    // autozero function x axis (first 10% of total values)
    for(i = 0; i <= 599; i++){
        autozerox = autozerox + adcval[i];
    }
    X_ZEROLINE = autozerox / 600;
    
    // Sending all x values via USART
    USART1_sendString("Shock data x axis: \r\n");
    for(i = 0; i <= (ADCVALUES - 1); i++){
        // Shift data to zero line and
        // convert voltage to acceleration
        zerovalues = adcval[i] - X_ZEROLINE;
        acceleration = (float)zerovalues;
        acceleration = acceleration * CONFACTOR;
        // Convert data to string
        ftoa(acceleration, strnum, 2);
        // Send data
        USART1_sendString(strnum);
        USART1_sendString(" ");

    }
    // End of data transfer
    USART1_sendString("\r\n");
    USART1_sendString("------------------------");

        
    //-------------------------------------------------
    
    // Second step: Read z-axis! 
    // Set all values to default		
    i = 0;
    x = 1;
    trigger_pos = -1;
    trigger_count = 0;

    // Read ADC values once in order to fill the data array with valid values before triggering. 
    // Shifting the array will lead to invalid values without previous filling. 
    for(i = 0; i < ADCVALUES - 1; i++){

        // Read y axis on pin PD5
        adcval[i] = ADC0_read_CH5();
    }

     // The following loop is for data acquisition. In this software version, x and z axis will be sampled. A third axis (y) can easily be added. 
    // 12500 values will be sampled every 4 �s. This corresponds to a signal length of 50 ms (might be necessary to modify, see above). 
    // The loop for data acquisition is an endless loop. This loop will only be left, when an trigger event is tripped (adc value above threshold). 
    // Before leaving the loop, 8750 more values will be sampled (corresponds to 35 ms). Together with the trigger index, data can be sorted so that
    // the array contains 15 ms of data before the trigger event and 35 ms of data after the trigger event. 
    while(x > 0){

        // Read y axis on pin PD5
        adcval[i] = ADC0_read_CH5();

        // If adc value is above threshold level, save trigger event index
        if((trigger_pos < 0) && ((adcval[i] > THRESLEVEL))){
            trigger_pos = i;
        }
        // increment counter
        i++;
        // when the counter reaches the end of the array: set counter to 0
        // that means, the measurement values are written continuously into the array
        if(i >= ADCVALUES){
            i = 0;
        }
        // If an trigger event was tripped: Start counting the number of measurements after trigger event
        if(trigger_pos >= 0){
            trigger_count++;
        }
        // Sample the desired number of measurement values after trigger event (here: 35 ms after trigger event), 
        // when the number of desired values is reached, leave the data acquisition loop
        if(trigger_count >= TRIGGERVALUES){
            x = 0;
        }
        // end of data acquisition loop
    }
    USART1_sendString("University of Applied Sciences Ruhr West, Napp/Schepers, SCHIRTE V3.0 \r\n");
    USART1_sendString("Trigger! Data will be transferred: \r\n");
    //_delay_ms(100);

    // Sorting procedure for data within array for z axis (i.e. 15 ms before and 35 ms after trigger event)
    // data will be shifted by DELTA positions within the arrays
    offset = trigger_pos - DELTA;

    if(offset > 0){
        // Shift array elements to the left
        for(i = 1; i <= offset; i++){
            // Saving the value of the first array element
            ztemp = adcval[0];
            
            for(j = 0; j < ADCVALUES - 1; j++){

                // Sorting index is set to the next field
                // and content will be written to actual field
                sortindex = j + 1;
                adcval[j] = adcval[sortindex];
               
            }

            // Content of the first array element is written to the last position of the array. 
            adcval[ADCVALUES - 1] = ztemp;
           
        }
    }
    else if(offset < 0){
        // shift array elements to the right
        offset = offset*(-1);
        for(i = 1; i <= offset; i++){
            // Saving the value of the last array element
            ztemp = adcval[ADCVALUES - 1];

            for(j = 0; j < ADCVALUES - 1; j++){

                // Start with the last array element and after that the counter moves step by step to the left, 
                // i. e. sorting index is decremented and content will be written to the actual element. 
                // Thus the content is moved to the right. 
                sortindex = ADCVALUES - j - 2;

                adcval[ADCVALUES - j - 1] = adcval[sortindex];

            }
            // Writing the content of the last element into the first field of the array. 
            adcval[0] = ztemp;
        }
    }

    // autozero function z axis (first 10% of total values)
    for(i = 0; i <= 599; i++){
        autozeroz = autozeroz + adcval[i];
    }
    Z_ZEROLINE = autozeroz / 600;
    
    // Sending all z values via USART
    USART1_sendString("Shock data z axis: \r\n");
    for(i = 0; i <= (ADCVALUES - 1); i++){
        // Shift data to zero line and
        // convert voltage to acceleration
        zerovalues = adcval[i] - Z_ZEROLINE;
        acceleration = (float)zerovalues;
        acceleration = acceleration * CONFACTOR;
        // Convert data to string
        ftoa(acceleration, strnum, 2);
        // Send data
        USART1_sendString(strnum);
        USART1_sendString(" ");

    }
    // End of data transfer
    USART1_sendString("\r\n");
    USART1_sendString("------------------------");
    
}
// End of readout functions
//***********************************************************